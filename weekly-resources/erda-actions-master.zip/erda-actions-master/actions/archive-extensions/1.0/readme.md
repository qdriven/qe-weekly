# Extensions 打包归档工具
将给定的 extensions 仓库打包为 `.tar.gz` 格式，上传到 OSS 存储。