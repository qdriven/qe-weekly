# Echo Action

echo what your typed.

## 使用

```yml
- echo:
    params:
      what: hello, dice action!
```
