# Echo Action

echo what your typed.

## 使用

```yml
- echo:
    params:
      # content 
      what: hello, dice action!
      # loop count
      count: 10
```
