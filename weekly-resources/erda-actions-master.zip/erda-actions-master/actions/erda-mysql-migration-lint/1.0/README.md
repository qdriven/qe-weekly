### Erda MySQL Migration Lint
Erda MySQL Migration 规约检查工具

#### 功能
该 Action 用于检查代码仓库中的 migrations 对《Erda MySQL 规约》中 migration 规约的合规性。
