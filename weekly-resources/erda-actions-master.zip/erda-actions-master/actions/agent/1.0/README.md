# Action Agent

action agent 是 action 运行时 pipeline 需要挂载的文件，作为 action 启动进程。action 二进制文件通过 image 进行分发。
