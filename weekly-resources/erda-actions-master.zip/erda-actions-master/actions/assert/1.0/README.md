## assert

```yaml
- assert:
    alias: assert
    version: "1.0"
    params:
      asserts:
        - value: "123"
          assert: "="
          assertValue: "123"
        - value: "123"
          assert: "="
          assertValue: "123"

```
