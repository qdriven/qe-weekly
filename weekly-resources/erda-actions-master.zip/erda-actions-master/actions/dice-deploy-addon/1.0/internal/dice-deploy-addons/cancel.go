package dice_deploy_addons

import (
	"github.com/erda-project/erda-actions/actions/dice-deploy-service/1.0/dice-deploy-services"
)

var Cancel = dice_deploy_services.Cancel
