docker build -t registry.erda.cloud/erda/android-gradle-node:v29 --no-cache \
 --build-arg http_proxy=http://30.43.41.107:1087  --build-arg https_proxy=http://30.43.41.107:1087 .