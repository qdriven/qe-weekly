package cloud.erda.analyzer.alert.models;

public enum AlertLevel {
    Breakdown,
    Emergency,
    Alert,
    Light
}