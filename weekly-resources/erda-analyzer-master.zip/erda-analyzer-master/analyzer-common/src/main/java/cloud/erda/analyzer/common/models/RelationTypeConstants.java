package cloud.erda.analyzer.common.models;

public class RelationTypeConstants {
    public static final String ALERT = "alert";
    public static final String EXCEPTION = "exception";
}
