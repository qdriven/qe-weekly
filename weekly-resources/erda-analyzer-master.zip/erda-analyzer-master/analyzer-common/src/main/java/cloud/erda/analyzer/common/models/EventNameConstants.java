package cloud.erda.analyzer.common.models;

public class EventNameConstants {
    public static final String ALERT = "alert";
    public static final String EXCEPTION = "exception";
}
