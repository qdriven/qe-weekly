package proto

// ensuring ensure package "github.com/erda-project/erda-infra/tools/gohub" available in build.sh
import _ "github.com/erda-project/erda-infra/pkg/transport"
