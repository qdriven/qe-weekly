# Cassandra Client Provider

The Cassandra Client Provider a simple encapsulation of Cassandra Client.
Provided concise APIs, and easy to do batch write.

### Configuration

```yaml
cassandra:
    host: "localhost:9042"
    # security: ${CASSANDRA_SECURITY_ENABLE:false}
    # username: ${CASSANDRA_SECURITY_USERNAME:}
    # password: ${CASSANDRA_SECURITY_PASSWORD:}
    # timeout: "${CASSANDRA_TIMEOUT:3s}"
```
