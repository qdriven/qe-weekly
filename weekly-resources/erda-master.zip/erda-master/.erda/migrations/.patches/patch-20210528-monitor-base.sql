ALTER TABLE sp_dashboard_block DEFAULT CHARACTER SET utf8;

ALTER TABLE sp_dashboard_block_system DEFAULT CHARACTER SET utf8;

ALTER TABLE sp_report_task DEFAULT CHARACTER SET utf8;
