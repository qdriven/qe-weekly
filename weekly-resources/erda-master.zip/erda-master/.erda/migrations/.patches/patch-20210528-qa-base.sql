ALTER TABLE dice_api_test MODIFY api_info LONGTEXT COMMENT 'API 信息';
