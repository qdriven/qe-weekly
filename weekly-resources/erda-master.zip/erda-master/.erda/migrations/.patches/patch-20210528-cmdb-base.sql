ALTER TABLE dice_config_namespace_relation DEFAULT CHARACTER SET utf8;

ALTER TABLE dice_member DEFAULT CHARACTER SET utf8;

