ALTER TABLE `erda_issue_subscriber` MODIFY `user_id` VARCHAR(191) COMMENT 'subscriber';
