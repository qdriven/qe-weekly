UPDATE dice_notify_items SET label = 'workbench' WHERE `name`='git_delete_branch' OR `name` = 'git_delete_tag'
