ALTER TABLE `dice_mboxs` MODIFY `deduplicate_id` VARCHAR(191) COMMENT 'deduplicate id';
