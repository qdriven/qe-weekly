update sp_alert_rules set name='平台组件日志存储保护器状态变化' where alert_index='dice_component_log_protector';
