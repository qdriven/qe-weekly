ALTER TABLE `dice_autotest_plan` ADD `execute_api_num` BIGINT NOT NULL DEFAULT 0 COMMENT 'auto test plan execute api number';
