ALTER TABLE `dice_autotest_plan_members` MODIFY column `user_id` varchar (255) NOT NULL DEFAULT "" COMMENT 'user_id';
