ALTER TABLE `dice_autotest_plan` ADD `iteration_id` bigint(20) NOT NULL DEFAULT 0 COMMENT 'iteration id';
