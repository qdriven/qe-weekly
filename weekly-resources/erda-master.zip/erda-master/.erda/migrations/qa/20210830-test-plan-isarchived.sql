ALTER TABLE `dice_test_plans` ADD `is_archived` boolean NOT NULL DEFAULT false COMMENT 'test plan is archived';
