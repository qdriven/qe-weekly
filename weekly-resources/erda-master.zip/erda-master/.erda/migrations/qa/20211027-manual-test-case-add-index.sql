ALTER TABLE `dice_test_cases` ADD INDEX `idx_test_set_id` (`test_set_id`);
