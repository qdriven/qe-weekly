ALTER TABLE `dice_test_plan_members` MODIFY column `user_id` varchar (255) NOT NULL DEFAULT "" COMMENT 'user_id';
