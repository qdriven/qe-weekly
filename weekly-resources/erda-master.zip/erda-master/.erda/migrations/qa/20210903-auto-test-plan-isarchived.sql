ALTER TABLE `dice_autotest_plan` ADD `is_archived` boolean NOT NULL DEFAULT false COMMENT 'auto test plan is archived';
