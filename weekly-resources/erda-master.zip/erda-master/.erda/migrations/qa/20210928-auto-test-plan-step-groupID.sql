ALTER TABLE `dice_autotest_plan_step` ADD `group_id` BIGINT(20) NOT NULL DEFAULT 0 COMMENT 'auto test plan step group';
