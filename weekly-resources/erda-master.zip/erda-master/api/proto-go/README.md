# erda-proto-go
Generated code from protobuf for Erda protobuf .

This repository depends on [erda-proto](https://github.com/erda-project/erda-proto)

## build
build all modules from *.proto files
```sh
make build
```
